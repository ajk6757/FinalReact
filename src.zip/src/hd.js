import "./App.css";


function Hd(){

    return(
        <div id="hdWrap">
        <div id="hd"></div>
        </div>
    )
}
export default Hd;