
import Muzip from './Muzip.js';
import './muzipFnc/animation.js';
import { Provider } from 'react-redux';
import store from './store/store';
import './muzipbar.css';
function MuzipWrap() {
  return (
    <Muzip/>
  )
}

export default MuzipWrap;
